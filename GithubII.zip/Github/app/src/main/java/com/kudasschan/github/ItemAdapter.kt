package com.kudasschan.github

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.kudasschan.github.api.dataclass.Users
import com.kudasschan.github.databinding.ItemUserBinding

class ItemAdapter : RecyclerView.Adapter<ItemAdapter.UsersViewHolder>() {
    private val list = ArrayList<Users>()
    private var onItemClickCallback: OnItemClickCallback? = null

    fun setonItemClickCallback(onItemClickCallback: OnItemClickCallback) {
        this.onItemClickCallback = onItemClickCallback
    }

    fun setlist(users: ArrayList<Users>) {
        list.clear()
        list.addAll(users)
        notifyDataSetChanged()
    }

    inner class UsersViewHolder(private val binding: ItemUserBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(users: Users) {
            binding.apply {
                Glide.with(itemView)
                    .load(users.avatar_url)
                    .centerCrop()
                    .into(profileImage)
                txtUsername.text = users.login
            }

            binding.root.setOnClickListener {
                onItemClickCallback?.onItemClick(users)
            }
        }
    }

    interface OnItemClickCallback {
        fun onItemClick(data: Users)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): UsersViewHolder {
        val view = ItemUserBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return UsersViewHolder((view))
    }

    override fun onBindViewHolder(holder: UsersViewHolder, position: Int) {
        holder.bind(list[position])
    }

    override fun getItemCount(): Int = list.size

}