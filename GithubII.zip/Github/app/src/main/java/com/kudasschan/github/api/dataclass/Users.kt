package com.kudasschan.github.api.dataclass

data class Users(
    val login: String,
    val id: Int,
    val avatar_url: String
)
