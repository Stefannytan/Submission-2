package com.kudasschan.github.api


import com.kudasschan.github.api.dataclass.DetailResponse
import com.kudasschan.github.api.dataclass.Users
import com.kudasschan.github.api.dataclass.UsersResponse
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Headers
import retrofit2.http.Path
import retrofit2.http.Query

interface ApiService {
    @GET("search/users")
    @Headers("Authorization: token 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")
    fun getSearchUsers(
        @Query("q") query: String
    ): Call<UsersResponse>

    @GET("users/{username}")
    @Headers("Authorization: token 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")
    fun getUsersDetail(
        @Path("username") username: String
    ): Call<DetailResponse>

    @GET("users/{username}/followers")
    @Headers("Authorization: token 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")
    fun getFollowers(
        @Path("username") Username: String
    ): Call<ArrayList<Users>>

    @GET("users/{username}/following")
    @Headers("Authorization: token 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")
    fun getFollowing(
        @Path("username") Username: String
    ): Call<ArrayList<Users>>
}