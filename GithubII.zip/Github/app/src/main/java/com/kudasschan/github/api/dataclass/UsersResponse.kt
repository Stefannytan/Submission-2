package com.kudasschan.github.api.dataclass

data class UsersResponse(
    val items: ArrayList<Users>
)
