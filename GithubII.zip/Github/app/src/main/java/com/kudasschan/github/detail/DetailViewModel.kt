package com.kudasschan.github.detail

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.kudasschan.github.api.dataclass.DetailResponse
import com.kudasschan.github.api.dataclass.RetrofitClient
import retrofit2.Call
import retrofit2.Response

class DetailViewModel : ViewModel() {
    val user = MutableLiveData<DetailResponse>()

    fun setUserDetail(username: String) {
        RetrofitClient.apiInstance
            .getUsersDetail(username)
            .enqueue(object : retrofit2.Callback<DetailResponse> {
                override fun onResponse(
                    call: Call<DetailResponse>,
                    response: Response<DetailResponse>
                ) {
                    if (response.isSuccessful) {
                        user.postValue(response.body())
                    }
                }

                override fun onFailure(call: Call<DetailResponse>, t: Throwable) {
                    Log.d("Error", t.message.toString())
                }
            })
    }

    fun getUserDetail(): LiveData<DetailResponse> {
        return user
    }
}